#'
#' This file contains functions to identify cohorts in a study.  Its
#' contents, as well as the contents of any R files whose name begins
#' with "cohort_", will be automatically sourced when the request is
#' executed.
#'
#' For simpler requests, it will often be possible to do all cohort
#' manipulation in functions within this file.  For more complex
#' requests, it may be more readable to separate different cohorts or
#' operations on cohorts into logical groups in different files.
#'
#'#'
#' This file contains functions to identify cohorts in a study.  Its
#' contents, as well as the contents of any R files whose name begins
#' with "cohort_", will be automatically sourced when the request is
#' executed.
#'
#' For simpler requests, it will often be possible to do all cohort
#' manipulation in functions within this file.  For more complex
#' requests, it may be more readable to separate different cohorts or
#' operations on cohorts into logical groups in different files.
#

#' Generate one-way table one for set of variables
#'
#' @param cohort cohort of interest
#' @param cat_vars vector of categorical variables
#' @param cont_var vector of continuous variables
#'
#' @return
#' @export
#'
#' @examples
get_table_one <- function(cohort, cat_vars = NULL, cont_var = NULL) {
	result <- list()

	if (
		is.null(cat_vars) &
			is.null(cont_var)
	) {
		stop(
			"Table one needs alteast one continuous or a categorical variable specified"
		)
	}

	if (!is.null(cat_vars)) {
		for (i in cat_vars) {
			result[[i]] <- cohort %>%
				count(!!sym(i)) %>%
				mutate(
					variable = paste0(i, "_", !!sym(i)),
					block = i,
					var_type = "cat",
					n = as.numeric(n)
				) %>%

				rename(
					Characteristics = !!sym(i),
					value = n
				) %>%
				collect_new()
		}
	}

	if (!is.null(cont_var)) {
		if (
			!any(
				class(get_argos_default()$config("db_src"))[1] ==
					c("PqConnection", "duckdb_connection", "src_BigQueryConnection")
			)
		) {
			for (i in cont_var) {
				result[[i]] <- cohort %>%
					mutate(
						mean = mean(!!sym(i), na.rm = T),
						sd = sd(!!sym(i), na.rm = T),
						median = median(!!sym(i)),
						quantile_25 = quantile(!!sym(i), 0.25),
						quantile_75 = quantile(!!sym(i), 0.75),
						block = i,
						var_type = "cont"
					) %>%
					distinct(
						mean,
						sd,
						median,
						quantile_25,
						quantile_75,
						block,
						var_type
					) %>%
					tidyr::pivot_longer(
						cols = c("mean", "median", "sd", "quantile_25", "quantile_75"),
						values_to = "value"
					) %>%
					mutate(
						variable = paste0(i, "_", name),
						block = i,
						var_type = "cont"
					) %>%
					rename(Characteristics = name) %>%
					collect_new()
			}
		} else {
			for (i in cont_var) {
				result[[i]] <- try(
					cohort %>%
						summarise(
							mean = mean(!!sym(i), na.rm = T),
							sd = sd(!!sym(i), na.rm = T),
							median = median(!!sym(i)),
							quantile_25 = quantile(!!sym(i), 0.25),
							quantile_75 = quantile(!!sym(i), 0.75),
							block = i,
							var_type = "cont"
						) %>%
						tidyr::pivot_longer(
							cols = c("mean", "median", "sd", "quantile_25", "quantile_75"),
							values_to = "value"
						) %>%
						mutate(variable = paste0(block, name)) %>%
						mutate(name = paste0(block, " ", name)) %>%
						rename(Characteristics = name) %>%
						collect_new(),
					silent = TRUE
				)

				if (any(class(result[[i]]) == "try-error")) {
					result[[i]] <- cohort %>%
						collect_new() %>%
						summarise(
							mean = mean(!!sym(i), na.rm = T),
							sd = sd(!!sym(i), na.rm = T),
							median = median(!!sym(i)),
							quantile_25 = quantile(!!sym(i), 0.25),
							quantile_75 = quantile(!!sym(i), 0.75),
							block = i,
							var_type = "cont"
						) %>%
						tidyr::pivot_longer(
							cols = c("mean", "median", "sd", "quantile_25", "quantile_75"),
							values_to = "value"
						) %>%
						mutate(variable = paste0(block, name)) %>%
						mutate(name = paste0(block, " ", name)) %>%
						rename(Characteristics = name)
				}
			}
		}
	}

	result[["total"]] <- cohort %>%
		count() %>%
		mutate(
			block = "Total",
			variable = "Total",
			Characteristics = "Total",
			var_type = "Total"
		) %>%
		mutate(n = as.numeric(n)) %>%
		rename(value = n) %>%
		collect_new()

	table_1 <- reduce(result, union_all) %>%
		select(block, variable, Characteristics, var_type, value)
	return(table_1)
}


in_memory_bash_cli_library <- function() {
	script <- '
#!/usr/bin/env bash

# A minimal Bash CLI styling library
BOLD="\\033[1m"
RESET="\\033[0m"
RED="\\033[31m"
GREEN="\\033[32m"
YELLOW="\\033[33m"
BLUE="\\033[34m"

cli_info() {
  echo -e "${BLUE}ℹ${RESET} $1"
}

cli_success() {
  echo -e "${GREEN}✔${RESET} $1"
}

cli_warning() {
  echo -e "${YELLOW}!${RESET} $1"
}

cli_error() {
  echo -e "${RED}✖${RESET} $1"
}

cli_heading() {
  echo -e "${BOLD}$1${RESET}"
  echo -e "${BOLD}----------------------------------------${RESET}"
}
'
	script
}


#' Function to echo terminal message while running a docker container with R in terminal
#'
#' @param text String of message to be generated. Dynamic object can be passed with paste0()
#'
#' @return
#' @export
#'
#' @examples
echo_text <- function(text, style = "info") {
	if (.Platform$OS.type == "windows") {
		sys.echo <-
			paste0("system('echo ", text, "')")

		source(textConnection(sys.echo))
	} else {
		script <- in_memory_bash_cli_library()

		bash_styles <- c(
			info = "cli_info",
			success = "cli_success",
			warning = "cli_warning",
			error = "cli_error",
			heading = "cli_heading"
		)

		if (!style %in% names(bash_styles)) {
			stop(
				"Unknown style '",
				style,
				"'. Valid styles are: ",
				paste(names(bash_styles), collapse = ", "),
				"."
			)
		}

		bash_function <- bash_styles[[style]]

		cmd <- sprintf(
			"bash << 'EOF'\n%s\n%s \"%s\"\nEOF",
			script,
			bash_function,
			text
		)

		system(cmd)
	}
	r_styles <- list(
		info = cli::cli_alert_info,
		success = cli::cli_alert_success,
		warning = cli::cli_alert_warning,
		error = cli::cli_alert_danger,
		heading = function(txt) cli::cli_h1(txt)
	)

	r_styles[[style]](text)
}

show_progress <- function(step, message) {
	progress_pct <- round(step / .GlobalEnv$total_steps * 100, 0)

	if (.Platform$OS.type == "windows") {
		text <- paste0("PROGRESS: ", progress_pct, "%\n")

		sys.echo <-
			paste0("system('echo ", text, "')")

		source(textConnection(sys.echo))
	} else {
		echo_text(paste0("PROGRESS: ", progress_pct, "%\n"))
	}

	cli::cli_h1(paste0("Step ", step, "/", total_steps, ": ", message))
}


#' Function to sink into log file
#'
#' @returns
#'
#' @export
#' @examples
start_log <- function() {
	logFile <- file(
		file.path(
			get_argos_default()$config("base_dir"),
			get_argos_default()$config("subdirs")$result_dir,
			paste0(.GlobalEnv$query_name, ".log")
		),
		open = "wt"
	)

	sink(file = logFile, type = "message", append = TRUE)
	sink(file = logFile, type = "output", append = TRUE)

	.GlobalEnv$query_start_time <- Sys.time()
}


#' Function to sink out of log file
#'
#' @returns
#'
#' @export
#' @examples
end_log <- function() {
	sink(type = "output")
	sink(type = "message")
	close.connection(logFile)

	.GlobalEnv$query_end_time <- Sys.time()

	signature <-
		tibble(
			`Query Start Time` = .GlobalEnv$query_start_time,
			`Query End Time` = .GlobalEnv$query_end_time,
			`Total Run Time` = .GlobalEnv$query_end_time - .GlobalEnv$query_start_time
		)
	output_tbl(rslt$signature, name = paste0('signature'))
}


#' Function to start rendering an html file
#'
#' @returns
#'
#' @export
#' @examples
render_report <- function() {
	if (Sys.getenv("native_execution") != "") {
		if (!as.logical(Sys.getenv("native_execution"))) {
			system(
				"quarto render query/script/report.qmd --output-dir ../results/ --execute-dir query/results/ --to html"
			)
		} else {
			quarto::quarto_render(
				"query/script/report.qmd",
				execute_dir = "query/results/"
			)
			file.rename(
				paste0("query/script/", .GlobalEnv$query_name, "_report.html"),
				paste0("query/results/", .GlobalEnv$query_name, "_report.html")
			)
		}
	} else {
		system(
			"quarto render query/script/report.qmd --output-dir ../results/ --execute-dir query/results/ --to html"
		)
	}
}
